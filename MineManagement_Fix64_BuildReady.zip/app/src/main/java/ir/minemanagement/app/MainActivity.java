package ir.minemanagement.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.Manifest;
import android.content.pm.PackageManager;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Build;

public class MainActivity extends Activity {
  WebView web;
  ValueCallback<Uri[]> uploadCallback;
  static final int FILE_CHOOSER=41;
  static final int LOCATION_PERMISSION=42;
  String pendingGeoOrigin;
  GeolocationPermissions.Callback pendingGeoCallback;
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true); s.setAllowContentAccess(true);
    s.setGeolocationEnabled(true);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
        if(url!=null && url.startsWith("https://chatgpt.com")){
          try { Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url)); startActivity(intent); }
          catch(Exception e){ view.loadUrl(url); }
          return true;
        }
        return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
        uploadCallback=cb;
        Intent i;
        try {
          i=params.createIntent();
          startActivityForResult(i,FILE_CHOOSER);
        } catch(Exception e) {
          ValueCallback<Uri[]> failed=uploadCallback;
          uploadCallback=null;
          if(failed!=null) failed.onReceiveValue(null);
          return true;
        }
        return true;
      }
      @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
           checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){
          callback.invoke(origin,true,false);
        } else if(Build.VERSION.SDK_INT>=23){
          pendingGeoOrigin=origin; pendingGeoCallback=callback;
          requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION);
        } else { callback.invoke(origin,false,false); }
      }
    });
    web.loadUrl("file:///android_asset/www/index.html");
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
    super.onRequestPermissionsResult(requestCode,permissions,grantResults);
    if(requestCode==LOCATION_PERMISSION && pendingGeoCallback!=null){
      boolean granted=false; for(int r:grantResults) if(r==PackageManager.PERMISSION_GRANTED)granted=true;
      pendingGeoCallback.invoke(pendingGeoOrigin,granted,false); pendingGeoCallback=null; pendingGeoOrigin=null;
    }
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_CHOOSER && uploadCallback!=null){
      Uri[] result=null;
      try {
        if(resultCode==RESULT_OK && data!=null)
          result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);
      } catch(Exception ignored) { result=null; }
      ValueCallback<Uri[]> cb=uploadCallback;
      uploadCallback=null;
      cb.onReceiveValue(result);
    }
  }
  @Override public void onBackPressed(){
    if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
